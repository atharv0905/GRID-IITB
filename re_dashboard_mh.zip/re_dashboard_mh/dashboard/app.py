# dashboard/app.py
from __future__ import annotations

import os
import json
import math
import re
from typing import Dict, List, Optional, Tuple

import requests
import pandas as pd

from dash import Dash, html, dcc, Input, Output, State, ctx, ALL, no_update
import dash_bootstrap_components as dbc
import dash_leaflet as dl
import plotly.graph_objects as go
from flask_caching import Cache

try:
    import geopandas as gpd
except Exception:
    gpd = None


# -----------------------------
# Config
# -----------------------------
DAYFIRST = os.environ.get("DAYFIRST", "1").strip() not in ("0", "false", "False", "no")

API_BASE = os.environ.get("API_BASE", "http://localhost:8001")
SHAPEFILE_PATH = os.environ.get("SHAPEFILE_PATH", "../data/India_State_Boundary_FIXED_4326.shp")

FORECAST_ORDER = ["Nowcasting", "Intra", "Inter", "Medium"]
FORECAST_TO_MODEL = {
    "Nowcasting": "NOWCAST",
    "Intra": "INTRA",
    "Inter": "INTER",
    "Medium": "MEDIUM",
}

COLOR_SOLAR = "#F4A340"
COLOR_WIND  = "#4A90E2"
BORDER_COLOR = "#000000"
BORDER_WEIGHT = 2.6
BORDER_OPACITY = 1.0
SELECTED_RING = "#FFD166"

SESSION = requests.Session()
SESSION.headers.update({"Connection": "keep-alive"})


def api_get(path: str, params: Optional[dict] = None) -> dict:
    url = f"{API_BASE}{path}"
    r = SESSION.get(url, params=params, timeout=30)
    r.raise_for_status()
    return r.json()


# -----------------------------
# Dash app + caching
# -----------------------------
app = Dash(__name__, external_stylesheets=[dbc.themes.DARKLY], suppress_callback_exceptions=True)
server = app.server

cache = Cache(
    server,
    config={
        "CACHE_TYPE": "filesystem",
        "CACHE_DIR": "./.dash_cache",
        "CACHE_DEFAULT_TIMEOUT": 120,
    },
)


# -----------------------------
# Cached API wrappers (NEW endpoints)
# -----------------------------
@cache.memoize(timeout=120)
def get_regions() -> List[dict]:
    return api_get("/regions")["items"]

@cache.memoize(timeout=120)
def get_plants(region_id: Optional[str] = None) -> List[dict]:
    params = {}
    if region_id:
        params["region_id"] = region_id
    return api_get("/plants", params=params)

def get_runs(limit: int = 800, model_name: Optional[str] = None, region_id: Optional[str] = None) -> List[dict]:
    params = {"limit": limit}
    if model_name:
        params["model_name"] = model_name
    if region_id:
        params["region_id"] = region_id
    return api_get("/runs", params=params)["items"]


def get_series(plant_id: str, run_id: str) -> List[dict]:
    return api_get("/series", params={"plant_id": plant_id, "run_id": run_id}).get("items", [])


# -----------------------------
# Boundary load once
# -----------------------------
def load_boundary_geojson(path: str) -> Tuple[Optional[dict], str]:
    if not path or not os.path.exists(path):
        return None, "Shapefile not found. Set SHAPEFILE_PATH."
    if gpd is None:
        return None, "geopandas not installed."
    try:
        gdf = gpd.read_file(path)
        try:
            gdf = gdf.to_crs(epsg=4326)
        except Exception:
            pass
        if gdf.empty:
            return None, "Boundary has 0 features."
        geo = json.loads(gdf.to_json())
        return geo, f"Loaded boundary features: {len(geo.get('features', []))}"
    except Exception as e:
        return None, f"Boundary load failed: {e}"

BOUNDARY_GEO, BOUNDARY_MSG = load_boundary_geojson(SHAPEFILE_PATH)


# -----------------------------
# Helpers
# -----------------------------
def marker_color(ptype: str) -> str:
    t = (ptype or "").lower()
    return COLOR_WIND if "wind" in t else COLOR_SOLAR

def series_to_df(items: List[dict]) -> pd.DataFrame:
    df = pd.DataFrame(items)
    if df.empty:
        return df

    # -------------------------
    # Time handling (fixes "UTC-looking" display)
    # -------------------------
    # 1) Prefer valid_time_raw (exact string from CSV).
    # 2) If missing, use valid_time_ist_local (computed in API from valid_time_utc).
    # 3) For plotting, interpret the chosen timestamp as IST.
    #
    # This avoids the common Postgres TIMESTAMPTZ behaviour where values are stored in UTC
    # and later *rendered* in UTC, which makes an IST run look like "previous day 23:30".
    raw_series = None
    if "valid_time_raw" in df.columns and df["valid_time_raw"].notna().any():
        raw_series = df["valid_time_raw"]
    elif "valid_time_ist_local" in df.columns and df["valid_time_ist_local"].notna().any():
        raw_series = df["valid_time_ist_local"]

    df["timestamp_raw"] = raw_series.astype(str) if raw_series is not None else None

    # Parse raw timestamp for plotting/sorting
    if df["timestamp_raw"].notna().any():
        ts = pd.to_datetime(df["timestamp_raw"], errors="coerce", dayfirst=DAYFIRST)
    else:
        ts = pd.Series([pd.NaT] * len(df))

    # Parse UTC fallback (tz-aware)
    if "valid_time_utc" in df.columns:
        df["valid_time_utc"] = pd.to_datetime(df["valid_time_utc"], errors="coerce", utc=True)

    # Ensure plot timestamp is IST-aware
    if getattr(ts.dt, "tz", None) is None:
        # interpret naive timestamps as IST
        try:
            ts = ts.dt.tz_localize("Asia/Kolkata")
        except Exception:
            pass

    # Fallback to UTC->IST conversion when raw missing/unparseable
    if "valid_time_utc" in df.columns:
        ts_fallback = df["valid_time_utc"].dt.tz_convert("Asia/Kolkata")
        ts = ts.fillna(ts_fallback)

    df["timestamp"] = ts

    # For table display: show raw string if present, else format IST local time
    df["timestamp_str"] = df["timestamp_raw"]
    if "timestamp" in df.columns:
        df["timestamp_str"] = df["timestamp_str"].fillna(
            df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
        )

    df = df.sort_values("timestamp")
    return df


def plot_pred_vs_actual(df: pd.DataFrame, pred_col: str, actual_col: str, title: str, ytitle: str) -> go.Figure:
    fig = go.Figure()
    if pred_col in df.columns and df[pred_col].notna().any():
        fig.add_trace(go.Scatter(
            x=df["timestamp"], y=df[pred_col],
            mode="lines+markers", name="Prediction",
            marker=dict(size=4)
        ))
    if actual_col in df.columns and df[actual_col].notna().any():
        fig.add_trace(go.Scatter(
            x=df["timestamp"], y=df[actual_col],
            mode="lines", name="Actual",
            line=dict(width=2)
        ))
    if len(fig.data) == 0:
        fig.add_annotation(text="No data", xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False)

    fig.update_layout(
        template="plotly_dark",
        height=320,
        margin=dict(l=12, r=12, t=44, b=10),
        title=title,
        xaxis_title="Time",
        yaxis_title=ytitle,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="rgba(233,238,246,.90)"),
    )
    return fig

def parse_revision_num(rev: str) -> int:
    # "R1" -> 1, "R12" -> 12, else 0
    m = re.search(r"(\d+)", str(rev or ""))
    return int(m.group(1)) if m else 0
def _parse_run_t0_dt(run: dict) -> pd.Timestamp:
    """
    Parse run t0 using preference:
      run_t0_raw -> run_t0_ist_local -> run_t0_utc
    Returns pandas Timestamp (NaT if cannot parse).
    """
    s = (run.get("run_t0_raw") or run.get("run_t0_ist_local") or run.get("run_t0_utc") or "").strip()
    if not s:
        return pd.NaT
    # robust parse; utc=True will handle +00:00 strings, naive strings become UTC then
    try:
        return pd.to_datetime(s, errors="coerce", utc=True)
    except Exception:
        return pd.NaT


def filter_runs_to_latest_t0(runs: List[dict]) -> List[dict]:
    """
    Keep only runs that belong to the latest run_t0 (latest cycle).
    """
    if not runs:
        return []
    dts = [(_parse_run_t0_dt(r), r) for r in runs]
    dts = [(dt, r) for dt, r in dts if pd.notna(dt)]
    if not dts:
        return runs  # if parsing failed, fall back to all
    latest_dt = max(dt for dt, _ in dts)
    # keep only same exact t0 timestamp (same cycle)
    return [r for dt, r in dts if dt == latest_dt]

def choose_run_by_revision(runs: List[dict], revision_choice: str) -> Optional[dict]:
    if not runs:
        return None

    # Always restrict to latest cycle first
    runs_latest = filter_runs_to_latest_t0(runs)

    # Sort latest-cycle runs by revision number (desc)
    runs_latest_sorted = sorted(
        runs_latest,
        key=lambda r: parse_revision_num(r.get("revision") or ""),
        reverse=True
    )

    if revision_choice == "LATEST":
        return runs_latest_sorted[0] if runs_latest_sorted else None

    # specific revision inside latest cycle
    for r in runs_latest_sorted:
        if (r.get("revision") or "").strip() == revision_choice:
            return r
    return None

def get_table_df(plant_id: str, run_id: str) -> pd.DataFrame:
    items = get_series(plant_id, run_id)
    df = series_to_df(items)
    if df.empty:
        return df

    preferred_cols = [
    "timestamp_str",
    "ghi_pred_wm2",
    "ghi_actual_wm2",
    "power_pred_mw",
    "power_actual_mw",
    "solar_power_pred_mw",
    "solar_power_actual_mw",
    "wind_power_pred_mw",
    "wind_power_actual_mw",
    ]

    cols = [c for c in preferred_cols if c in df.columns]
    tdf = df[cols].copy() if cols else df.copy()

    rename_map = {
    "timestamp_str": "Time",
    "ghi_pred_wm2": "GHI prediction (W/m²)",
    "ghi_actual_wm2": "GHI actual (W/m²)",
    "power_pred_mw": "Power prediction (MW)",
    "power_actual_mw": "Power actual (MW)",
    "solar_power_pred_mw": "Solar power prediction (MW)",
    "solar_power_actual_mw": "Solar power actual (MW)",
    "wind_power_pred_mw": "Wind Power prediction (MW)",
    "wind_power_actual_mw": "Wind Power actual (MW)",
    }

    tdf = tdf.rename(columns={k: v for k, v in rename_map.items() if k in tdf.columns})

    numeric_cols = tdf.select_dtypes(include=["float64", "float32", "int64", "int32"]).columns
    if len(numeric_cols) > 0:
        tdf[numeric_cols] = tdf[numeric_cols].round(2)

    # if "Time" in tdf.columns:
    #     tdf["Time"] = tdf["Time"].astype(str)

    return tdf


def blank_fig() -> go.Figure:
    f = go.Figure()
    f.update_layout(
        template="plotly_dark",
        height=320,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=12, r=12, t=44, b=10),
    )
    return f


# -----------------------------
# Layout
# -----------------------------
app.layout = dbc.Container(
    fluid=True,
    children=[
        dcc.Location(id="url"),
        dcc.Store(id="store_regions"),
        dcc.Store(id="store_plants"),
        dcc.Store(id="store_runs"),
        dcc.Store(id="store_selected_run"),
        dcc.Store(id="store_marker_click"),  # ADD THIS LINE
        dcc.Download(id="download_csv"),

        html.Div(
            [
                html.H2("GRID-INDIA IITB Forecast Dashboard", className="page-title"),
                html.Div("Nowcasting • Intra • Inter • Medium", className="page-subtitle"),
            ]
        ),

        dbc.Row(
            [
                # Controls
                dbc.Col(
                    html.Div(
                        [
                            html.H5("Controls", className="section-title"),
                            html.Hr(),

                            dbc.Label("Forecast"),
                            dcc.Dropdown(
                                id="dd_forecast",
                                options=[{"label": k, "value": k} for k in FORECAST_ORDER],
                                value="Nowcasting",
                                clearable=False,
                            ),

                            html.Br(),
                            dbc.Label("Region"),
                            dcc.Dropdown(id="dd_region", options=[], value=None, clearable=False),

                            html.Br(),
                            dbc.Label("Plant"),
                            dcc.Dropdown(id="dd_plant", options=[], value=None, clearable=False),

                            html.Br(),
                            dbc.Label("Revision"),
                            dcc.Dropdown(id="dd_revision", options=[], value="LATEST", clearable=False),

                            html.Hr(),
                            dbc.Checklist(
                                id="ck_autorefresh",
                                options=[{"label": "Auto-refresh", "value": "on"}],
                                value=["on"],
                                switch=True,
                            ),

                            dbc.Label("Refresh interval (minutes)"),
                            dcc.Slider(
                                id="sl_refresh",
                                min=5, max=60, step=None,
                                value=5,
                                marks={5:"5",10:"10",15:"15",30:"30",60:"60"},
                            ),

                            dcc.Interval(id="interval", interval=5*60*1000, n_intervals=0, disabled=False),

                            html.Hr(),
                            html.Div(id="plant_meta", style={"opacity": 0.85}),
                        ],
                        className="panel",
                    ),
                    md=3, lg=3, className="h-100",
                ),

                # Map
                dbc.Col(
                    html.Div(
                        [
                            html.H5("Geospatial View", className="section-title"),
                            dcc.Loading(
                                type="circle",
                                children=html.Div(
                                    dl.Map(
                                        id="map",
                                        center=[22.0, 78.0],
                                        zoom=5,
                                        style={"width": "100%", "height": "560px", "borderRadius": "14px"},
                                        children=[
                                            dl.LayersControl(
                                                position="topright",
                                                collapsed=True,
                                                children=[
                                                    dl.BaseLayer(
                                                        dl.TileLayer(
                                                            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
                                                            attribution="Esri",
                                                        ),
                                                        name="Satellite (Esri)",
                                                        checked=True,
                                                    ),
                                                    dl.BaseLayer(
                                                        dl.TileLayer(
                                                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                                                            attribution="OpenStreetMap",
                                                        ),
                                                        name="Street (OSM)",
                                                        checked=False,
                                                    ),
                                                    dl.Overlay(dl.LayerGroup(id="boundary_layer"), name="India boundary", checked=True),
                                                    dl.Overlay(dl.LayerGroup(id="plants_group"), name="Plants", checked=True),
                                                    dl.Overlay(dl.LayerGroup(id="selected_group"), name="Selected", checked=True),
                                                ],
                                            )
                                        ],
                                    ),
                                    className="map-wrap",
                                ),
                            ),
                            html.Div(
                                ("" if BOUNDARY_GEO else f"Boundary: {BOUNDARY_MSG}"),
                                style={"opacity": 0.7, "marginTop": "6px", "fontSize": "12px"},
                            ),
                        ],
                        className="panel map-panel",
                    ),
                    md=7, lg=7, className="h-100",
                ),

                # Summary (vertical)
                dbc.Col(
                    html.Div(
                        [
                            html.H5("Summary", className="section-title"),
                            html.Div(id="kpi_cards", className="summary-stack"),
                        ],
                        className="panel",
                    ),
                    md=2, lg=2, className="h-100",
                ),
            ],
            className="g-3 align-items-stretch",
        ),

        html.Br(),

        # Charts with separate borders
        html.Div(
            [
                html.H5("Forecast Graphs", className="section-title"),
                dcc.Loading(
                    type="circle",
                    children=html.Div(
                        [
                            html.Div(dcc.Graph(id="g1"), className="chart-card"),
                            html.Div(dcc.Graph(id="g2"), className="chart-card"),
                            html.Div(dcc.Graph(id="g3"), className="chart-card"),
                            html.Div(dcc.Graph(id="g4"), className="chart-card"),
                        ],
                        className="charts-grid",
                    ),
                ),
            ],
            className="panel",
        ),

        html.Br(),

        # Table + download
        html.Div(
            [
                dbc.Row(
                    [
                        dbc.Col(html.H5("Data", className="section-title"), width=6),
                        dbc.Col(
                            dbc.Button("Download CSV", id="btn_download", color="secondary", size="sm"),
                            width=6,
                            className="text-end",
                        ),
                    ]
                ),
                html.Br(),
                dcc.Loading(type="circle", children=html.Div(id="table_container")),
            ],
            className="panel",
        ),
    ],
)


# -----------------------------
# Callbacks
# -----------------------------
@app.callback(
    Output("store_regions", "data"),
    Output("dd_region", "options"),
    Output("dd_region", "value"),
    Input("url", "pathname"),
)
def init_regions(_):
    try:
        regions = get_regions()
    except Exception:
        return [], [], None

    opts = [{"label": "All", "value": "ALL"}] + [
        {"label": (r.get("region_name") or r.get("region_code") or "Region"), "value": r["region_id"]}
        for r in regions
    ]
    return regions, opts, "ALL"

def normalize_items(x):
    """
    Accepts list/dict/json-string and returns a list[dict].
    This prevents: TypeError: string indices must be integers
    """
    if x is None:
        return []

    # If already list
    if isinstance(x, list):
        return [i for i in x if isinstance(i, dict)]

    # If dict: common API patterns
    if isinstance(x, dict):
        if isinstance(x.get("items"), list):
            return [i for i in x["items"] if isinstance(i, dict)]
        if isinstance(x.get("data"), list):
            return [i for i in x["data"] if isinstance(i, dict)]
        # sometimes dict is {id: {...}, ...}
        vals = list(x.values())
        if vals and all(isinstance(v, dict) for v in vals):
            return vals
        return []

    # If string: maybe JSON string
    if isinstance(x, str):
        s = x.strip()
        if not s:
            return []
        try:
            j = json.loads(s)
            return normalize_items(j)
        except Exception:
            return []

    return []

@app.callback(
    Output("store_plants", "data"),
    Output("dd_plant", "options"),
    Output("dd_plant", "value"),
    Input("dd_region", "value"),
)
def update_plants(region_id):
    if not region_id:
        return [], [], None

    try:
        raw = get_plants(None if region_id == "ALL" else region_id)
    except Exception:
        return [], [], None

    plants = normalize_items(raw)

    # keep only valid rows
    plants = [p for p in plants if isinstance(p, dict) and p.get("plant_id") and p.get("plant_name")]

    opts = [{"label": p["plant_name"], "value": p["plant_id"]} for p in plants]
    default = opts[0]["value"] if opts else None
    return plants, opts, default



@app.callback(
    Output("interval", "interval"),
    Output("interval", "disabled"),
    Input("sl_refresh", "value"),
    Input("ck_autorefresh", "value"),
)
def update_interval(refresh_mins, autoval):
    refresh_mins = int(refresh_mins or 5)
    enabled = (autoval and "on" in autoval)
    return refresh_mins * 60 * 1000, (not enabled)


@app.callback(
    Output("boundary_layer", "children"),
    Input("url", "pathname"),
)
def render_boundary(_):
    if not BOUNDARY_GEO:
        return []
    return dl.GeoJSON(
        data=BOUNDARY_GEO,
        options=dict(style=dict(color=BORDER_COLOR, weight=BORDER_WEIGHT, opacity=BORDER_OPACITY, fillOpacity=0)),
    )


@app.callback(
    Output("plants_group", "children"),
    Input("store_plants", "data"),
    Input("dd_plant", "value"),
)
def build_markers(plants, selected_plant_id):
    plants = plants or []
    markers = []
    for p in plants:
        pid = p["plant_id"]
        is_sel = (pid == selected_plant_id)
        fill = marker_color(p.get("plant_type", ""))

        markers.append(
            dl.CircleMarker(
                id={"type": "plant-marker", "plant_id": pid},
                center=[float(p["lat"]), float(p["lon"])],
                radius=9 if is_sel else 5,
                color=SELECTED_RING if is_sel else fill,
                weight=3 if is_sel else 1.5,
                fill=True,
                fillColor=fill,
                fillOpacity=0.9 if is_sel else 0.75,
                children=[dl.Tooltip(p["plant_name"])],
            )
        )
    return markers


@app.callback(
    Output("selected_group", "children"),
    Output("map", "center"),
    Output("map", "zoom"),
    Input("dd_plant", "value"),
    State("store_plants", "data"),
)
def update_selected_marker(plant_id, plants):
    plants = plants or []
    sel = next((p for p in plants if p.get("plant_id") == plant_id), None)
    if not sel:
        return [], [22.0, 78.0], 5
    lat, lon = float(sel["lat"]), float(sel["lon"])
    return [], [lat, lon], 7


@app.callback(
    Output("dd_plant", "value", allow_duplicate=True),
    Output("store_marker_click", "data"),  # ADD THIS OUTPUT
    Input({"type": "plant-marker", "plant_id": ALL}, "n_clicks_timestamp"),
    State("store_plants", "data"),
    prevent_initial_call=True,
)
def click_marker(ts_list, plants):
    if not ts_list or all(t is None for t in ts_list):
        return no_update, no_update

    # pick most recently clicked marker
    max_idx = max(range(len(ts_list)), key=lambda i: ts_list[i] or -1)

    # plants list order matches marker creation order -> use same indexing
    if not plants or max_idx >= len(plants):
        return no_update, no_update

    plant_id = plants[max_idx]["plant_id"]
    return plant_id, {"clicked": True}  # Signal marker was clicked


# Make sure update_revision_dropdown is properly connected
@app.callback(
    Output("store_runs", "data"),
    Output("dd_revision", "options"),
    Output("dd_revision", "value"),
    Input("dd_forecast", "value"),
    Input("dd_plant", "value"),
    Input("interval", "n_intervals"),   # keep this so it refreshes automatically
    State("store_plants", "data"),
)
def update_revision_dropdown(forecast_ui, plant_id, _n, plants):
    model_name = FORECAST_TO_MODEL.get(forecast_ui or "Nowcasting", "NOWCAST")

    region_id = None
    if plant_id and plants:
        p = next((x for x in plants if x.get("plant_id") == plant_id), None)
        region_id = p.get("region_id") if p else None

    try:
        rlist = get_runs(limit=1200, model_name=model_name, region_id=region_id)
    except Exception:
        return [], [{"label": "Latest", "value": "LATEST"}], "LATEST"

    # ✅ keep only latest run_t0 cycle so revisions are ONLY for "today/latest"
    rlist_latest = filter_runs_to_latest_t0(rlist)

    revs = sorted(
        {str(r.get("revision") or "").strip() for r in rlist_latest if str(r.get("revision") or "").strip()},
        key=lambda x: parse_revision_num(x),
        reverse=True
    )

    opts = [{"label": "Latest (latest run t0)", "value": "LATEST"}] + [{"label": rev, "value": rev} for rev in revs]
    return rlist_latest, opts, "LATEST"


@app.callback(
    Output("download_csv", "data"),
    Input("btn_download", "n_clicks"),
    State("dd_forecast", "value"),
    State("dd_plant", "value"),
    State("dd_revision", "value"),
    State("store_runs", "data"),
    State("store_plants", "data"),
    prevent_initial_call=True,
)
def download_table(_n, forecast_ui, plant_id, revision_choice, runs_store, plants):
    if not plant_id:
        return no_update

    model_name = FORECAST_TO_MODEL.get(forecast_ui or "Nowcasting", "NOWCAST")

    # filter runs to this plant's region (safety)
    region_id = None
    if plants:
        p = next((x for x in plants if x.get("plant_id") == plant_id), None)
        region_id = p.get("region_id") if p else None

    runs = [r for r in (runs_store or []) if (not region_id or r.get("region_id") == region_id)]
    runs = [r for r in runs if (r.get("model_name") or "").upper() == model_name.upper()]

    run = choose_run_by_revision(runs, revision_choice or "LATEST")
    if not run:
        return no_update

    tdf = get_table_df(plant_id, run["run_id"])
    if tdf.empty:
        return no_update

    return dcc.send_data_frame(tdf.to_csv, "forecast_series.csv", index=False)


@app.callback(
    Output("kpi_cards", "children"),
    Output("plant_meta", "children"),
    Output("g1", "figure"),
    Output("g2", "figure"),
    Output("g3", "figure"),
    Output("g4", "figure"),
    Output("table_container", "children"),
    Input("dd_forecast", "value"),
    Input("dd_plant", "value"),
    Input("dd_revision", "value"),
    Input("interval", "n_intervals"),
    Input("store_marker_click", "data"),  # ADD THIS INPUT
    State("store_plants", "data"),
    State("store_runs", "data"),
)
def update_all(forecast_ui, plant_id, revision_choice, _n, marker_click, plants, runs_store):
    if not plant_id or not forecast_ui:
        msg = dbc.Alert("Select forecast and plant.", color="warning")
        return msg, "", blank_fig(), blank_fig(), blank_fig(), blank_fig(), ""

    model_name = FORECAST_TO_MODEL.get(forecast_ui, "NOWCAST")

    plant = next((p for p in (plants or []) if p.get("plant_id") == plant_id), None)
    if not plant:
        msg = dbc.Alert("Plant not found in current selection.", color="warning")
        return msg, "", blank_fig(), blank_fig(), blank_fig(), blank_fig(), ""

    region_id = plant.get("region_id")

    runs = [r for r in (runs_store or []) if (r.get("region_id") == region_id)]
    runs = [r for r in runs if (r.get("model_name") or "").upper() == model_name.upper()]

    run = choose_run_by_revision(runs, revision_choice or "LATEST")
    if not run:
        msg = dbc.Alert("No runs found yet for this selection. Wait for ingestion.", color="warning")
        meta = html.Div([html.Div(f"Lat/Lon: {float(plant['lat']):.4f}, {float(plant['lon']):.4f}")])
        return msg, meta, blank_fig(), blank_fig(), blank_fig(), blank_fig(), msg

    run_id = run["run_id"]
    rev = run.get("revision", "")

    items = get_series(plant_id, run_id)
    df = series_to_df(items)
    if df.empty:
        msg = dbc.Alert("No prediction rows yet for this plant/revision. Wait for DB update.", color="warning")
        meta = html.Div([html.Div(f"Lat/Lon: {float(plant['lat']):.4f}, {float(plant['lon']):.4f}")])
        return msg, meta, blank_fig(), blank_fig(), blank_fig(), blank_fig(), msg

    # ===== FIX: Use latest valid_time as Run t0 instead of run_t0_utc =====
    # For Nowcasting: latest valid_time is 15 mins in the past from run start
    # For Medium: run created at 05:30 AM daily
    run_t0_display = ""
    if "timestamp_str" in df.columns and df["timestamp_str"].notna().any():
        # Use latest timestamp from data as reference
        latest_ts = df["timestamp_str"].iloc[-1]
        run_t0_display = str(latest_ts)
    elif "timestamp" in df.columns and df["timestamp"].notna().any():
        # Fallback: use timestamp column
        latest_ts = df["timestamp"].iloc[-1]
        run_t0_display = latest_ts.strftime("%Y-%m-%d %H:%M:%S")
    else:
        # Ultimate fallback: use raw run data
        run_t0_display = run.get("run_t0_raw") or run.get("run_t0_ist_local") or run.get("run_t0_utc") or ""

    meta = html.Div(
        [
            html.Div(f"Type: {plant.get('plant_type','')}", style={"marginBottom": "4px"}),
            html.Div(f"Lat/Lon: {float(plant['lat']):.4f}, {float(plant['lon']):.4f}"),
            html.Div(f"Revision: {rev}  |  Run t0: {run_t0_display}", style={"marginTop": "6px", "opacity": 0.85}),
        ]
    )

    avg_ghi = float(df["ghi_pred_wm2"].mean()) if "ghi_pred_wm2" in df.columns else 0.0
    peak_ghi = float(df["ghi_pred_wm2"].max()) if "ghi_pred_wm2" in df.columns else 0.0
    latest_time = ""
    if "timestamp_str" in df.columns and df["timestamp_str"].notna().any():
        latest_time = str(df["timestamp_str"].iloc[-1])
    elif "timestamp" in df.columns and df["timestamp"].notna().any():
        latest_time = df["timestamp"].iloc[-1].strftime("%Y-%m-%d %H:%M")

    kpis = html.Div(
        [
            html.Div(
                [
                    html.Div(f"{avg_ghi:.0f} W/m²", className="kpi-value"),
                    html.Div("Average predicted GHI", className="kpi-label"),
                    html.Div(f"Peak: {peak_ghi:.0f} W/m²", className="kpi-sub"),
                ],
                className="kpi-tile",
            ),
            html.Div(
                [
                    html.Div(latest_time, className="kpi-value"),
                    html.Div("Latest timestamp", className="kpi-label"),
                    html.Div(f"{rev}", className="kpi-sub"),
                ],
                className="kpi-tile",
            ),
        ],
        className="summary-stack",
    )

    fig1 = plot_pred_vs_actual(df, "ghi_pred_wm2", "ghi_actual_wm2", "GHI Prediction vs Actual", "W/m²")
    fig2 = plot_pred_vs_actual(df, "solar_power_pred_mw", "solar_power_actual_mw", "Solar Power Prediction vs Actual", "MW")
    fig3 = plot_pred_vs_actual(df, "wind_power_pred_mw", "wind_power_actual_mw", "Wind Power Prediction vs Actual", "MW")
    
    # ===== CHANGE: g4 now shows blank graph instead of Total Power =====
    fig4 = blank_fig()

    tdf = get_table_df(plant_id, run_id)
    if tdf.empty:
        table = dbc.Alert("No table rows for this selection.", color="warning")
        return kpis, meta, fig1, fig2, fig3, fig4, table

    table = dbc.Table.from_dataframe(
        tdf.head(500),
        striped=True,
        bordered=True,
        hover=True,
        responsive=True,
        color="dark",
        class_name="table-sm align-middle mb-0 table-centered"
    )

    return kpis, meta, fig1, fig2, fig3, fig4, table


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8050, debug=True)
